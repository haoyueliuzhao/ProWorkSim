def test_value():
    from sample import value
    assert value == 2
